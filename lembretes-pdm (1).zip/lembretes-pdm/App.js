import Lembrete from './components/Lembrete.js'
import Notification from './components/Notification'


const App = () =>{
return <Lembrete/>;

}


export default App